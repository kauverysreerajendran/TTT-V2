from django.apps import AppConfig


class NickelAuditConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Nickel_Audit'

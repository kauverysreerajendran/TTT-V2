from django.shortcuts import render

def spider_pick_table(request):
    return render(request, 'Spider_Spindle/Spider_Pick_Table.html')
from django.apps import AppConfig


class SpiderSpindleConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Spider_Spindle'
